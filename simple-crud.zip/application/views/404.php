<!DOCTYPE html>
<html>
<head>
	<title>Error 404 - Page Not Found</title>
</head>
<body>
	<h1>Error Pages</h1>
</body>
</html>