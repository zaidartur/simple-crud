		<?php
		//$tgl1 = date('Y-m-d');// pendefinisian tanggal awal
		$tgl2 = date('d F Y', strtotime('+7 days', strtotime(date('Y-m-d')))); 
		?>

    <hr>
    <div class="container">
        <center> Zaid Artur &copy;2018 <?php echo "- ".$tgl2; ?></center>
    </div>

</div>

</body>
</html>
